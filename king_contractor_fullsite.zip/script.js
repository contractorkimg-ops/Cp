// i18n (EN + HI)
const i18n = {
  en: {
    nav_home: "Home", nav_about:"About", nav_services:"Services", nav_contact:"Contact",
    hero_title: "Fast, professional home & office services",
    slogan: siteConfig.slogan,
    quick_contact: "Quick Contact",
    get_estimate: "Get a Free Estimate",
    our_services: "Our Services",
    s1:"Marble Installation & Reinstallation", s1d:"Expert fitting, polishing and repairs.",
    s2:"Home & Office Painting", s2d:"Clean, durable finishes in any color.",
    s3:"Air Conditioning (AC)", s3d:"Installation, servicing & repair.",
    s4:"Plumbing & Leaks", s4d:"Quick fixes and full installs.",
    s5:"Electrical", s5d:"Safe wiring, lights & fixtures.",
    s6:"General Contracting", s6d:"Renovations, tiling, and more.",
    serving:"Serving",
    about_title:"About King Contractor",
    about_p1:"We provide fast, reliable marble, painting, AC, electrical and plumbing services across Kuwait.",
    about_p2:"With years of experience, we focus on quality materials, clear pricing and on-time delivery.",
    services_title:"Services",
    sv1:"Marble Installation & Reinstallation", sv1a:"Floor & wall tiling", sv1b:"Polishing & sealing", sv1c:"Repair & re-level",
    sv2:"Painting (Home & Office)", sv2a:"Interior/Exterior", sv2b:"Waterproof & anti-fungal", sv2c:"Feature walls & textures",
    sv3:"AC (Air Conditioning)", sv3a:"Split/duct install", sv3b:"Gas refill & service", sv3c:"Fault repair",
    sv4:"Plumbing", sv4a:"Leak fix & fitting", sv4b:"Bathroom/kitchen install",
    sv5:"Electrical", sv5a:"Wiring & sockets", sv5b:"Lights & fans",
    sv6:"General Contracting", sv6a:"Renovation & civil", sv6b:"Maintenance contracts",
    contact_title:"Contact Us", name:"Your Name", email:"Your Email", msg:"Your Inquiry", send:"Send Inquiry",
    thanks:"Thank you! We received your inquiry.", reply:"We will call you soon.", back_home:"Back to Home",
    whatsapp:"WhatsApp"
  },
  hi: {
    nav_home:"होम", nav_about:"हमारे बारे में", nav_services:"सेवाएँ", nav_contact:"संपर्क",
    hero_title:"घरों और ऑफ़िस के लिए तेज़ और प्रोफ़ेशनल सेवाएँ",
    slogan: "मैं 2 घंटे में आपके पास पहुँच कर समस्या का समाधान देता हूँ!",
    quick_contact:"त्वरित संपर्क",
    get_estimate:"फ्री अनुमान पाएं",
    our_services:"हमारी सेवाएँ",
    s1:"मार्बल इंस्टॉलेशन व रीइंस्टॉलेशन", s1d:"एक्सपर्ट फिटिंग, पॉलिशिंग और रिपेयर।",
    s2:"होम व ऑफ़िस पेंटिंग", s2d:"साफ़-सुथरी, टिकाऊ फिनिश।",
    s3:"ए.सी. (एयर कंडीशनिंग)", s3d:"इंस्टॉलेशन, सर्विसिंग व रिपेयर।",
    s4:"प्लंबिंग व लीकेज", s4d:"फास्ट फिक्स और इंस्टॉलेशन।",
    s5:"इलेक्ट्रिकल", s5d:"सेफ़ वायरिंग, लाइट्स व फिक्स्चर।",
    s6:"जनरल कॉन्ट्रैक्टिंग", s6d:"रिनोवेशन, टाइलिंग इत्यादि।",
    serving:"सेवा क्षेत्र",
    about_title:"किंग कॉन्ट्रैक्टर के बारे में",
    about_p1:"हम कुवैत में मार्बल, पेंटिंग, ए.सी., इलेक्ट्रिकल और प्लंबिंग की तेज़ व भरोसेमंद सेवाएँ देते हैं।",
    about_p2:"सालों के अनुभव के साथ, हम गुणवत्ता, साफ़ दाम और समय पर डिलीवरी पर फोकस करते हैं।",
    services_title:"सेवाएँ",
    sv1:"मार्बल इंस्टॉलेशन व रीइंस्टॉलेशन", sv1a:"फ़्लोर व वाल टाइलिंग", sv1b:"पॉलिशिंग व सीलिंग", sv1c:"रिपेयर व री-लेवल",
    sv2:"पेंटिंग (होम व ऑफ़िस)", sv2a:"इंटीरियर/एक्सटीरियर", sv2b:"वॉटरप्रूफ व एंटी-फंगल", sv2c:"फ़ीचर वॉल्स व टेक्सचर",
    sv3:"ए.सी.", sv3a:"स्प्लिट/डक्ट इंस्टॉल", sv3b:"गैस रिफ़िल व सर्विस", sv3c:"फ़ॉल्ट रिपेयर",
    sv4:"प्लंबिंग", sv4a:"लीक फिक्स व फिटिंग", sv4b:"बाथरूम/किचन इंस्टॉल",
    sv5:"इलेक्ट्रिकल", sv5a:"वायरिंग व सॉकेट्स", sv5b:"लाइट्स व फ़ैन",
    sv6:"जनरल कॉन्ट्रैक्टिंग", sv6a:"रिनोवेशन व सिविल", sv6b:"मेंटेनेंस कॉन्ट्रैक्ट्स",
    contact_title:"संपर्क करें", name:"आपका नाम", email:"आपका ईमेल", msg:"आपकी क्वेरी", send:"भेजें",
    thanks:"धन्यवाद! आपकी क्वेरी मिल गई है।", reply:"हम जल्द कॉल करेंगे।", back_home:"होम पर जाएँ",
    whatsapp:"व्हाट्सऐप"
  }
};

let currentLang = localStorage.getItem("lang") || "en";
function setLang(lang){
  currentLang = lang; localStorage.setItem("lang", lang);
  applyLang();
}
function t(key){ return (i18n[currentLang] && i18n[currentLang][key]) || (i18n.en[key]||key); }

function applyLang(){
  const map = [
    ["t-nav-home","nav_home"],["t-nav-about","nav_about"],["t-nav-services","nav_services"],["t-nav-contact","nav_contact"],
    ["t-hero-title","hero_title"],["t-slogan","slogan"],["t-quick-contact","quick_contact"],["t-get-estimate","get_estimate"],
    ["t-our-services","our_services"],["t-s1","s1"],["t-s1d","s1d"],["t-s2","s2"],["t-s2d","s2d"],["t-s3","s3"],["t-s3d","s3d"],
    ["t-s4","s4"],["t-s4d","s4d"],["t-s5","s5"],["t-s5d","s5d"],["t-s6","s6"],["t-s6d","s6d"],
    ["t-about-title","about_title"],["t-about-p1","about_p1"],["t-about-p2","about_p2"],
    ["t-services-title","services_title"],["t-sv1","sv1"],["t-sv1a","sv1a"],["t-sv1b","sv1b"],["t-sv1c","sv1c"],
    ["t-sv2","sv2"],["t-sv2a","sv2a"],["t-sv2b","sv2b"],["t-sv2c","sv2c"],
    ["t-sv3","sv3"],["t-sv3a","sv3a"],["t-sv3b","sv3b"],["t-sv3c","sv3c"],
    ["t-sv4","sv4"],["t-sv4a","sv4a"],["t-sv4b","sv4b"],
    ["t-sv5","sv5"],["t-sv5a","sv5a"],["t-sv5b","sv5b"],
    ["t-sv6","sv6"],["t-sv6a","sv6a"],["t-sv6b","sv6b"],
    ["t-contact-title","contact_title"],
    ["t-name","name"],["t-email","email"],["t-msg","msg"],["t-send","send"],
    ["t-thanks","thanks"],["t-reply","reply"],["t-back-home","back_home"],
    ["t-whatsapp","whatsapp"],["t-serving","serving"]
  ];
  map.forEach(([id,key])=>{ const el=document.getElementById(id); if(el){ if(el.placeholder!==undefined && el.tagName==="INPUT"){ el.placeholder=t(key);} else if(el.tagName==="TEXTAREA"){ el.placeholder=t(key);} else { el.textContent=t(key);} } });
  // company/service area in header
  const comp = document.getElementById("t-company"); if(comp) comp.textContent = siteConfig.companyName;
  const area = document.getElementById("t-service-area"); if(area) area.textContent = siteConfig.serviceArea;
  const year = document.getElementById("year"); if(year) year.textContent = new Date().getFullYear();
}

document.addEventListener("DOMContentLoaded", ()=>{
  applyLang();
  // CountAPI: visit
  fetch(`https://api.countapi.xyz/hit/${encodeURIComponent(siteConfig.counters.namespace)}/${encodeURIComponent(siteConfig.counters.visitKey)}`)
    .then(r=>r.json()).then(d=>{ const el=document.getElementById("visitCount"); if(el) el.textContent = d.value; }).catch(()=>{});
  // Show inquiry count
  fetch(`https://api.countapi.xyz/get/${encodeURIComponent(siteConfig.counters.namespace)}/${encodeURIComponent(siteConfig.counters.inquiryKey)}`)
    .then(r=>r.json()).then(d=>{ const el=document.getElementById("inquiryCount"); if(el) el.textContent = d.value ?? 0; }).catch(()=>{});
  // GA inject
  if(siteConfig.gaId && siteConfig.gaId !== "G-XXXXXXXX"){
    const s=document.createElement("script"); s.async=true; s.src=`https://www.googletagmanager.com/gtag/js?id=${siteConfig.gaId}`; document.head.appendChild(s);
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);} window.gtag=gtag;
    gtag('js', new Date()); gtag('config', siteConfig.gaId);
  }
});

function countInquiry(){
  fetch(`https://api.countapi.xyz/hit/${encodeURIComponent(siteConfig.counters.namespace)}/${encodeURIComponent(siteConfig.counters.inquiryKey)}`)
    .then(r=>r.json()).then(d=>{ const el=document.getElementById("inquiryCount"); if(el) el.textContent = d.value; }).catch(()=>{});
}
