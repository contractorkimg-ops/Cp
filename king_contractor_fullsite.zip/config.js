const siteConfig = {
  companyName: "King Contractor",
  slogan: "I reach your place within 2 hours and give you the solution!",
  phoneDisplay: "+965 60415225",
  phoneWhatsapp: "96560415225",
  email: "contractorkimg@gmail.com",
  address: "Near American School, Khaitan, Kuwait",
  serviceArea: "All Kuwait",
  gaId: "G-XXXXXXXX", // <-- replace with your Google Analytics ID
  counters: {
    namespace: "kingcontractor:site",
    visitKey: "visits",
    inquiryKey: "inquiries"
  }
};