KING CONTRACTOR — Vercel-ready static site

FILES
- index.html        Home + counters + quick contact
- about.html        About page
- services.html     Services list
- contact.html      Email inquiry form (FormSubmit) + increments inquiry counter
- thankyou.html     Redirect after form submit
- config.js         Edit company info, service area, GA ID, counter keys
- script.js         Language (EN/HI), CountAPI counters, GA injection
- style.css         Styles
- vercel.json       Static deploy rules

SETUP
1) Deploy: Upload this folder to a GitHub repo, then Import to Vercel (or drag & drop).
2) Email: First time FormSubmit will send a verification email to contractorkimg@gmail.com; approve it once.
3) Analytics: Put your Google Analytics Measurement ID in config.js (gaId).
4) Edit address/area/phone in config.js.
5) Counters: Using CountAPI. No login. Keys live in config.js; you can change namespace if you want.

NOTE
Storing full inquiry messages requires a database or a third‑party (e.g., Google Sheets App Script). This starter tracks counts and emails inquiries. If you want saving to Google Sheet, ask and we'll add a free connector.
